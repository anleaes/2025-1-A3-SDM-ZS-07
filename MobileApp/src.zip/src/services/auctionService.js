import axios from 'axios';

const API_URL = 'http://127.0.0.1:8000/api';

// USUÁRIO
export const registerUser = async (userData) => {
  const response = await axios.post(`${API_URL}/users/register/`, userData);
  return response.data;
};

export const loginUser = async (credentials) => {
  const response = await axios.post(`${API_URL}/users/login/`, credentials);
  return response.data;
};

// LEILÕES
export const createAuction = async (auctionData) => {
  const response = await axios.post(`${API_URL}/auctions/`, auctionData);
  return response.data;
};

export const getAuctions = async () => {
  const response = await axios.get(`${API_URL}/auctions/`);
  return response.data;
};

export const getAuctionDetails = async (id) => {
  const response = await axios.get(`${API_URL}/auctions/${id}/`);
  return response.data;
};

// LANCES
export const placeBid = async (bidData) => {
  const response = await axios.post(`${API_URL}/bids/`, bidData);
  return response.data;
};
