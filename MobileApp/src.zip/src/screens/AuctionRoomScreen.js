import React, { useState, useRef } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  Animated,
} from 'react-native';
import colors from '../styles/colors';

export default function AuctionRoomScreen() {
  const [bid, setBid] = useState('');
  const [bids, setBids] = useState([]);
  const fadeAnim = useRef(new Animated.Value(0)).current;

  const handlePlaceBid = () => {
    if (!bid || isNaN(bid)) {
      alert('Digite um valor válido.');
      return;
    }

    const newBid = {
      id: Date.now().toString(),
      amount: parseFloat(bid),
    };

    setBids([newBid, ...bids]);
    setBid('');

    // Animação de entrada do lance
    fadeAnim.setValue(0);
    Animated.timing(fadeAnim, {
      toValue: 1,
      duration: 600,
      useNativeDriver: true,
    }).start();
  };

  const renderBidItem = ({ item }) => (
    <Animated.View style={{ opacity: fadeAnim }}>
      <Text style={styles.bidItem}>💰 R$ {item.amount.toFixed(2)}</Text>
    </Animated.View>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>🔥 Sala de Leilão</Text>

      <TextInput
        style={styles.input}
        placeholder="Digite seu lance"
        placeholderTextColor="#aaa"
        keyboardType="numeric"
        value={bid}
        onChangeText={setBid}
      />

      <TouchableOpacity style={styles.button} onPress={handlePlaceBid} activeOpacity={0.8}>
        <Text style={styles.buttonText}>Dar Lance</Text>
      </TouchableOpacity>

      <Text style={styles.subtitle}>📋 Lances Recentes</Text>

      <FlatList
        data={bids}
        keyExtractor={(item) => item.id}
        renderItem={renderBidItem}
        ListEmptyComponent={<Text style={styles.emptyText}>Nenhum lance ainda.</Text>}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.black,
    padding: 24,
  },
  title: {
    fontSize: 26,
    color: colors.gold,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 20,
  },
  input: {
    borderWidth: 1,
    borderColor: colors.gold,
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    color: '#fff',
    fontSize: 16,
    marginBottom: 12,
  },
  button: {
    backgroundColor: colors.gold,
    paddingVertical: 14,
    borderRadius: 10,
    marginBottom: 24,
    shadowColor: colors.gold,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 5,
    elevation: 6,
  },
  buttonText: {
    color: colors.black,
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 20,
    color: colors.gold,
    marginBottom: 10,
    fontWeight: '600',
  },
  bidItem: {
    color: '#fff',
    paddingVertical: 8,
    borderBottomColor: '#333',
    borderBottomWidth: 1,
    fontSize: 16,
  },
  emptyText: {
    color: '#777',
    fontStyle: 'italic',
    textAlign: 'center',
    marginTop: 20,
  },
});
